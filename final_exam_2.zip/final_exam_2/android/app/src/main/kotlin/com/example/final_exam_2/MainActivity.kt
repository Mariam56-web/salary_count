package com.example.final_exam_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
